import { createFileRoute } from "@tanstack/react-router";
import { Activity, CalendarDays, Gavel, HeartPulse, LineChart, Trees, Home, CheckCircle2 } from "lucide-react";
import { LayoutSwitcher } from "@/components/site/LayoutSwitcher";
import { AtividadeFisicaChart, CansacoChart, DiaExtraChart, LazerChart } from "@/components/site/Charts";
import { escala, lei, nav, numeros, perspectiva, resultados, siteInfo } from "@/content/site";

export const Route = createFileRoute("/painel")({
  head: () => ({
    meta: [
      { title: "Vida além da escala — Layout Painel" },
      { name: "description", content: "Painel de dados sobre o fim da escala 6x1: números da lei aprovada, perspectivas para saúde e lazer e gráficos da pesquisa." },
      { property: "og:title", content: "Vida além da escala — Layout Painel" },
      { property: "og:description", content: "O fim da escala 6x1 em formato de painel de dados interativo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Painel,
});

const navIcons = { inicio: Home, escala: CalendarDays, lei: Gavel, perspectiva: HeartPulse, resultados: LineChart };
const eixoIcons = [Activity, Trees, HeartPulse];

function Tag({ children }: { children: React.ReactNode }) {
  return <p className="font-mono text-[11px] tracking-[0.18em] text-primary uppercase">{children}</p>;
}

function Panel({ className = "", children }: { className?: string; children: React.ReactNode }) {
  return <div className={`rounded-xl border border-border bg-card p-6 text-card-foreground shadow-card ${className}`}>{children}</div>;
}

function Painel() {
  return (
    <div className="theme-painel min-h-screen bg-background pb-24 font-sans text-foreground">
      <div className="mx-auto flex max-w-7xl gap-8 px-4 md:px-6">
        {/* Sidebar */}
        <aside className="sticky top-0 hidden h-screen w-56 shrink-0 flex-col py-8 lg:flex">
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-primary" />
            <span className="font-semibold">Vida além da escala</span>
          </div>
          <p className="mt-1 font-mono text-xs text-muted-foreground">{siteInfo.turma}</p>
          <nav className="mt-10 flex flex-col gap-1">
            {nav.map((n) => {
              const Icon = navIcons[n.id];
              return (
                <a key={n.id} href={`#${n.id}`} className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground">
                  <Icon className="h-4 w-4" /> {n.label}
                </a>
              );
            })}
          </nav>
          <div className="mt-auto rounded-lg bg-secondary p-4">
            <p className="font-mono text-[11px] text-muted-foreground uppercase">Status</p>
            <p className="mt-1 flex items-center gap-2 text-sm"><CheckCircle2 className="h-4 w-4 text-primary" /> PEC promulgada</p>
          </div>
        </aside>

        <main className="min-w-0 flex-1 space-y-24 py-8">
          {/* Início */}
          <section id="inicio" className="space-y-6">
            <div className="relative overflow-hidden rounded-2xl border border-border bg-card p-8 md:p-12 grid-dots">
              <Tag>Painel · Escala 6x1 · Out 2026</Tag>
              <h1 className="mt-4 max-w-3xl animate-rise text-5xl font-bold leading-[1] text-balance-tight md:text-7xl">
                Menos horas na semana. <span className="text-primary">Mais vida no fim dela.</span>
              </h1>
              <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{siteInfo.subtitulo}</p>
            </div>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {numeros.map((n, i) => (
                <Panel key={n.valor}>
                  <p className={`text-3xl font-bold md:text-4xl ${i % 2 === 0 ? "text-primary" : "text-accent"}`}>{n.valor}</p>
                  <p className="mt-2 text-sm text-muted-foreground">{n.rotulo}</p>
                </Panel>
              ))}
            </div>
          </section>

          {/* Escala */}
          <section id="escala" className="space-y-6">
            <div>
              <Tag>01 / Entenda</Tag>
              <h2 className="mt-2 text-4xl font-bold text-balance-tight md:text-5xl">O que é a escala 6x1</h2>
            </div>
            <div className="grid gap-4 md:grid-cols-5">
              <Panel className="md:col-span-3">
                <p className="leading-relaxed text-muted-foreground">{escala.resumo}</p>
                <div className="mt-6 space-y-4">
                  {[{ nome: "6x1", dias: escala.semana6x1, h: "44h" }, { nome: "5x2", dias: escala.semana5x2, h: "40h" }].map((s) => (
                    <div key={s.nome} className="flex items-center gap-4">
                      <span className="w-10 font-mono text-sm">{s.nome}</span>
                      <div className="grid flex-1 grid-cols-7 gap-1.5">
                        {s.dias.map((d, i) => (
                          <div key={i} title={escala.dias[i]} className={`flex h-10 items-center justify-center rounded-md font-mono text-[11px] ${d === "F" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>
                            {escala.dias[i]}
                          </div>
                        ))}
                      </div>
                      <span className="w-10 text-right font-mono text-sm text-accent">{s.h}</span>
                    </div>
                  ))}
                </div>
              </Panel>
              <div className="grid gap-4 md:col-span-2">
                {escala.pontos.map((p) => (
                  <Panel key={p.titulo} className="p-5">
                    <h3 className="font-semibold">{p.titulo}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{p.texto}</p>
                  </Panel>
                ))}
              </div>
            </div>
          </section>

          {/* Lei */}
          <section id="lei" className="space-y-6">
            <div>
              <Tag>02 / Lei aprovada</Tag>
              <h2 className="mt-2 text-4xl font-bold text-balance-tight md:text-5xl">{lei.nome}</h2>
              <p className="mt-4 max-w-3xl text-muted-foreground">{lei.resumo}</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {lei.mudancas.map((m, i) => (
                <Panel key={m.titulo}>
                  <p className="font-mono text-xs text-accent">0{i + 1}</p>
                  <h3 className="mt-3 text-lg font-semibold">{m.titulo}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{m.texto}</p>
                </Panel>
              ))}
            </div>
            <Panel>
              <p className="mb-6 font-mono text-xs text-muted-foreground uppercase">Tramitação</p>
              <ol className="grid gap-6 md:grid-cols-7 md:gap-3">
                {lei.linhaDoTempo.map((t, i) => (
                  <li key={t.data} className="relative md:pt-6">
                    <span className={`absolute top-0 left-0 hidden h-1 w-full rounded-full md:block ${i === lei.linhaDoTempo.length - 1 ? "bg-primary" : "bg-secondary"}`} />
                    <p className="font-mono text-sm text-primary">{t.data}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{t.evento}</p>
                  </li>
                ))}
              </ol>
            </Panel>
          </section>

          {/* Perspectiva */}
          <section id="perspectiva" className="space-y-6">
            <div>
              <Tag>03 / Perspectivas</Tag>
              <h2 className="mt-2 text-4xl font-bold text-balance-tight md:text-5xl">Atividade física, lazer e bem-estar</h2>
              <p className="mt-4 max-w-3xl text-muted-foreground">{perspectiva.introducao}</p>
              <p className="mt-2 font-mono text-xs text-muted-foreground">{perspectiva.credito}</p>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {perspectiva.eixos.map((e, i) => {
                const Icon = eixoIcons[i] ?? Activity;
                return (
                  <Panel key={e.titulo} className="flex flex-col">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/15 text-primary">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h3 className="mt-5 text-xl font-semibold">{e.titulo}</h3>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{e.texto}</p>
                    <div className="mt-6 border-t border-border pt-4">
                      <p className="text-2xl font-bold text-accent">{e.destaque}</p>
                      <p className="text-xs text-muted-foreground">{e.destaqueRotulo}</p>
                    </div>
                  </Panel>
                );
              })}
            </div>
            <Panel>
              <p className="font-mono text-xs text-muted-foreground uppercase">Desafios</p>
              <ul className="mt-4 grid gap-3 md:grid-cols-3">
                {perspectiva.desafios.map((d) => (
                  <li key={d} className="flex gap-2 text-sm"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> {d}</li>
                ))}
              </ul>
            </Panel>
          </section>

          {/* Resultados */}
          <section id="resultados" className="space-y-6">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <Tag>04 / Pesquisa</Tag>
                <h2 className="mt-2 text-4xl font-bold text-balance-tight md:text-5xl">Resultados e discussões</h2>
                <p className="mt-2 text-sm text-muted-foreground">{resultados.amostra}</p>
              </div>
              <p className="rounded-full border border-accent px-3 py-1 font-mono text-xs text-accent">{resultados.aviso}</p>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Panel><h3 className="mb-4 font-semibold">Dias de atividade física por semana</h3><AtividadeFisicaChart /></Panel>
              <Panel><h3 className="mb-4 font-semibold">Nível de cansaço (escala 6x1)</h3><CansacoChart /></Panel>
              <Panel><h3 className="mb-4 font-semibold">Horas de lazer por semana</h3><LazerChart /></Panel>
              <Panel><h3 className="mb-4 font-semibold">O que fariam com o dia extra</h3><DiaExtraChart /></Panel>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {resultados.discussao.map((d, i) => (
                <Panel key={i} className="p-5">
                  <p className="font-mono text-xs text-primary">Discussão {i + 1}</p>
                  <p className="mt-2 text-sm leading-relaxed">{d}</p>
                </Panel>
              ))}
            </div>
            <p className="font-mono text-xs text-muted-foreground">{resultados.credito}</p>
          </section>

          <footer className="border-t border-border pt-8 text-sm text-muted-foreground">
            <p>{siteInfo.turma} · Fontes:{" "}
              {lei.fontes.map((f, i) => (
                <span key={f.url}>
                  <a href={f.url} target="_blank" rel="noreferrer" className="text-primary hover:underline">{f.nome}</a>
                  {i < lei.fontes.length - 1 ? " · " : ""}
                </span>
              ))}
            </p>
          </footer>
        </main>
      </div>
      <LayoutSwitcher />
    </div>
  );
}

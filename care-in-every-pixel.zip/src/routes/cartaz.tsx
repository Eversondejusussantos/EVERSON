import { createFileRoute } from "@tanstack/react-router";
import cartaz from "@/assets/cartaz-calendario.jpg";
import { LayoutSwitcher } from "@/components/site/LayoutSwitcher";
import { AtividadeFisicaChart, CansacoChart, DiaExtraChart, LazerChart } from "@/components/site/Charts";
import { escala, lei, nav, numeros, perspectiva, resultados, siteInfo } from "@/content/site";

export const Route = createFileRoute("/cartaz")({
  head: () => ({
    meta: [
      { title: "Vida além da escala — Layout Cartaz" },
      { name: "description", content: "O fim da escala 6x1 em estilo cartaz: o que muda com a PEC 221/2019 e o que a pesquisa revela sobre saúde e lazer." },
      { property: "og:title", content: "Vida além da escala — Layout Cartaz" },
      { property: "og:description", content: "Fim da 6x1: dois dias de descanso, 40 horas semanais e mais tempo para o corpo e o lazer." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Cartaz,
});

const marquee = ["Fim da 6x1", "40 horas", "2 dias de descanso", "Sem redução de salário", "Mais lazer", "Mais saúde"];

function Block({ className = "", children }: { className?: string; children: React.ReactNode }) {
  return <div className={`border-[3px] border-border bg-card p-6 text-card-foreground shadow-brutal ${className}`}>{children}</div>;
}

function Title({ n, children }: { n: string; children: React.ReactNode }) {
  return (
    <div className="mb-10 flex items-start gap-4">
      <span className="bg-secondary px-3 py-1 font-display text-2xl text-secondary-foreground">{n}</span>
      <h2 className="font-display text-5xl leading-[0.9] uppercase md:text-7xl">{children}</h2>
    </div>
  );
}

function Cartaz() {
  return (
    <div className="theme-cartaz min-h-screen bg-background pb-24 font-sans text-foreground">
      <header className="sticky top-0 z-40 border-b-[3px] border-border bg-secondary text-secondary-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
          <a href="#inicio" className="font-display text-lg uppercase">Vida além da escala</a>
          <nav className="hidden gap-5 text-sm font-semibold uppercase md:flex">
            {nav.map((n) => (
              <a key={n.id} href={`#${n.id}`} className="hover:text-primary">{n.label}</a>
            ))}
          </nav>
        </div>
      </header>

      {/* Início */}
      <section id="inicio" className="mx-auto grid max-w-6xl gap-10 px-6 pt-12 pb-16 md:grid-cols-[1.3fr_1fr] md:items-center">
        <div>
          <p className="inline-block bg-primary px-3 py-1 text-sm font-bold text-primary-foreground uppercase">{siteInfo.turma} · Promulgado em 16/10/2026</p>
          <h1 className="mt-6 animate-rise font-display text-6xl leading-[0.85] uppercase md:text-[7.5rem]">
            Seis por um <span className="block text-primary">nunca mais.</span>
          </h1>
          <p className="mt-6 max-w-lg text-xl font-medium">{siteInfo.subtitulo}</p>
          <a href="#lei" className="mt-8 inline-block border-[3px] border-border bg-secondary px-6 py-3 font-display text-secondary-foreground uppercase shadow-brutal transition-transform hover:-translate-y-1">
            Entenda a lei →
          </a>
        </div>
        <img src={cartaz} alt="Ilustração de punho erguido segurando um calendário com dois dias destacados" width={1024} height={1280} className="w-full border-[3px] border-border shadow-brutal-lg" />
      </section>

      <div className="overflow-hidden border-y-[3px] border-border bg-primary py-3 text-primary-foreground">
        <div className="flex w-max animate-marquee gap-10 font-display text-2xl uppercase">
          {[...marquee, ...marquee].map((m, i) => (
            <span key={i} className="flex items-center gap-10">{m}<span>★</span></span>
          ))}
        </div>
      </div>

      <main className="mx-auto max-w-6xl space-y-28 px-6 pt-20">
        <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
          {numeros.map((n) => (
            <Block key={n.valor} className="p-5">
              <p className="font-display text-3xl md:text-4xl">{n.valor}</p>
              <p className="mt-2 text-sm font-medium">{n.rotulo}</p>
            </Block>
          ))}
        </div>

        {/* Escala */}
        <section id="escala">
          <Title n="01">O que é a 6x1?</Title>
          <div className="grid gap-8 md:grid-cols-2">
            <p className="text-xl leading-relaxed font-medium">{escala.resumo}</p>
            <Block className="bg-secondary text-secondary-foreground">
              {[{ nome: "Antes: 6x1", dias: escala.semana6x1 }, { nome: "Agora: 5x2", dias: escala.semana5x2 }].map((s) => (
                <div key={s.nome} className="mb-6 last:mb-0">
                  <p className="mb-2 font-display uppercase">{s.nome}</p>
                  <div className="grid grid-cols-7 gap-1">
                    {s.dias.map((d, i) => (
                      <div key={i} className={`py-3 text-center text-xs font-bold uppercase ${d === "F" ? "bg-primary text-primary-foreground" : "bg-background text-foreground"}`}>
                        {escala.dias[i]}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </Block>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {escala.pontos.map((p) => (
              <Block key={p.titulo}>
                <h3 className="font-display text-xl uppercase">{p.titulo}</h3>
                <p className="mt-2">{p.texto}</p>
              </Block>
            ))}
          </div>
        </section>

        {/* Lei */}
        <section id="lei">
          <Title n="02">A lei passou!</Title>
          <p className="max-w-3xl text-xl font-medium">{lei.resumo}</p>
          <div className="mt-10 grid gap-6 sm:grid-cols-2">
            {lei.mudancas.map((m, i) => (
              <Block key={m.titulo} className={i % 2 === 1 ? "bg-primary text-primary-foreground" : ""}>
                <h3 className="font-display text-3xl uppercase">{m.titulo}</h3>
                <p className="mt-2 text-lg">{m.texto}</p>
              </Block>
            ))}
          </div>
          <ol className="mt-12 grid gap-0 border-[3px] border-border md:grid-cols-7">
            {lei.linhaDoTempo.map((t, i) => (
              <li key={t.data} className={`border-b-[3px] border-border p-4 last:border-b-0 md:border-r-[3px] md:border-b-0 md:last:border-r-0 ${i === lei.linhaDoTempo.length - 1 ? "bg-secondary text-secondary-foreground" : "bg-card"}`}>
                <p className="font-display text-lg uppercase">{t.data}</p>
                <p className="mt-1 text-sm">{t.evento}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* Perspectiva */}
        <section id="perspectiva">
          <Title n="03">Tempo pro corpo, pro lazer, pra você</Title>
          <p className="max-w-3xl text-xl font-medium">{perspectiva.introducao}</p>
          <p className="mt-2 text-sm font-bold uppercase">{perspectiva.credito}</p>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {perspectiva.eixos.map((e) => (
              <Block key={e.titulo} className="flex flex-col">
                <p className="font-display text-4xl text-primary">{e.destaque}</p>
                <p className="text-xs font-bold uppercase">{e.destaqueRotulo}</p>
                <h3 className="mt-6 font-display text-2xl uppercase">{e.titulo}</h3>
                <p className="mt-2 flex-1">{e.texto}</p>
              </Block>
            ))}
          </div>
          <Block className="mt-8 bg-secondary text-secondary-foreground">
            <h3 className="font-display text-2xl uppercase">Os desafios</h3>
            <ul className="mt-4 grid gap-4 md:grid-cols-3">
              {perspectiva.desafios.map((d, i) => (
                <li key={d} className="flex gap-3"><span className="font-display text-3xl text-primary">{i + 1}</span>{d}</li>
              ))}
            </ul>
          </Block>
        </section>

        {/* Resultados */}
        <section id="resultados">
          <Title n="04">O que a pesquisa mostra</Title>
          <div className="flex flex-wrap items-center gap-4">
            <p className="font-medium">{resultados.amostra}</p>
            <p className="bg-secondary px-3 py-1 text-sm font-bold text-secondary-foreground uppercase">{resultados.aviso}</p>
          </div>
          <div className="mt-10 grid gap-8 md:grid-cols-2">
            <Block><h3 className="mb-4 font-display uppercase">Dias de atividade física</h3><AtividadeFisicaChart /></Block>
            <Block><h3 className="mb-4 font-display uppercase">Cansaço na escala 6x1</h3><CansacoChart /></Block>
            <Block><h3 className="mb-4 font-display uppercase">Horas de lazer por semana</h3><LazerChart /></Block>
            <Block><h3 className="mb-4 font-display uppercase">E com o dia extra?</h3><DiaExtraChart /></Block>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {resultados.discussao.map((d, i) => (
              <Block key={i} className={i === 1 ? "bg-primary text-primary-foreground" : ""}>
                <p className="font-display text-3xl">#{i + 1}</p>
                <p className="mt-2 text-lg">{d}</p>
              </Block>
            ))}
          </div>
          <p className="mt-6 text-sm font-bold uppercase">{resultados.credito}</p>
        </section>
      </main>

      <footer className="mt-28 border-t-[3px] border-border bg-secondary px-6 py-10 text-secondary-foreground">
        <div className="mx-auto max-w-6xl">
          <p className="font-display text-4xl uppercase">Vida além da escala</p>
          <p className="mt-2 text-sm">{siteInfo.turma} · Fontes:{" "}
            {lei.fontes.map((f, i) => (
              <span key={f.url}>
                <a href={f.url} target="_blank" rel="noreferrer" className="underline hover:text-primary">{f.nome}</a>
                {i < lei.fontes.length - 1 ? ", " : ""}
              </span>
            ))}
          </p>
        </div>
      </footer>
      <LayoutSwitcher />
    </div>
  );
}

import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { nav, siteInfo } from "@/content/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Vida além da escala — O fim da escala 6x1" },
      { name: "description", content: "Site da turma 632 sobre o fim da escala 6x1: a lei aprovada, perspectivas para atividade física, lazer e bem-estar e resultados da pesquisa. Escolha entre 3 layouts." },
      { property: "og:title", content: "Vida além da escala — O fim da escala 6x1" },
      { property: "og:description", content: "Escala 6x1, lei aprovada, perspectivas e resultados da pesquisa em três layouts para escolha." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const layouts = [
  { to: "/editorial", n: "01", nome: "Editorial", desc: "Estilo jornal: tipografia serifada, papel e tinta, leitura longa.", theme: "theme-editorial", sample: "Um dia a mais para viver." },
  { to: "/painel", n: "02", nome: "Painel", desc: "Painel de dados escuro: números em destaque e gráficos em cartões.", theme: "theme-painel", sample: "Menos horas. Mais vida." },
  { to: "/cartaz", n: "03", nome: "Cartaz", desc: "Cartaz de manifesto: cores fortes, letras enormes e blocos marcados.", theme: "theme-cartaz", sample: "6x1 nunca mais." },
] as const;

function Index() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <main className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <p className="text-sm font-medium tracking-[0.2em] text-primary uppercase">{siteInfo.turma} · Projeto escolar</p>
        <h1 className="mt-4 max-w-4xl animate-rise font-display text-6xl leading-[0.95] text-balance-tight md:text-8xl">
          {siteInfo.titulo}
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{siteInfo.subtitulo}</p>

        <div className="mt-10 flex flex-wrap gap-2">
          {nav.map((n, i) => (
            <span key={n.id} className="rounded-full border border-border px-3 py-1 text-sm">
              <span className="mr-1 text-muted-foreground">{i + 1}.</span>{n.label}
            </span>
          ))}
        </div>

        <h2 className="mt-20 font-display text-4xl md:text-5xl">Escolha um layout</h2>
        <p className="mt-2 text-muted-foreground">Os três têm o mesmo conteúdo. Dentro de cada um, use a barra inferior para comparar.</p>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {layouts.map((l) => (
            <Link key={l.to} to={l.to} className="group block overflow-hidden rounded-xl border border-border bg-card shadow-card transition-transform hover:-translate-y-1">
              <div className={`${l.theme} flex aspect-[4/3] flex-col justify-between bg-background p-5 text-foreground`}>
                <div className="flex gap-1.5">
                  <span className="h-2 w-8 bg-primary" />
                  <span className="h-2 w-4 bg-foreground/30" />
                  <span className="h-2 w-4 bg-foreground/30" />
                </div>
                <p className="font-display text-4xl leading-[0.95]">{l.sample}</p>
                <div className="grid grid-cols-3 gap-1.5">
                  <span className="h-8 rounded-sm bg-card shadow-card" />
                  <span className="h-8 rounded-sm bg-primary" />
                  <span className="h-8 rounded-sm bg-card shadow-card" />
                </div>
              </div>
              <div className="flex items-start justify-between gap-4 border-t border-border p-5">
                <div>
                  <p className="text-xs text-muted-foreground">Layout {l.n}</p>
                  <h3 className="font-display text-3xl">{l.nome}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{l.desc}</p>
                </div>
                <ArrowUpRight className="h-5 w-5 shrink-0 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import descanso from "@/assets/descanso-parque.jpg";
import { LayoutSwitcher } from "@/components/site/LayoutSwitcher";
import { AtividadeFisicaChart, CansacoChart, DiaExtraChart, LazerChart } from "@/components/site/Charts";
import { escala, lei, nav, numeros, perspectiva, resultados, siteInfo } from "@/content/site";

export const Route = createFileRoute("/editorial")({
  head: () => ({
    meta: [
      { title: "Vida além da escala — Layout Editorial" },
      { name: "description", content: "Reportagem sobre o fim da escala 6x1, a PEC 221/2019 e seus efeitos na atividade física, no lazer e no bem-estar." },
      { property: "og:title", content: "Vida além da escala — Layout Editorial" },
      { property: "og:description", content: "O fim da escala 6x1 contado em formato de jornal: lei aprovada, perspectivas e resultados da pesquisa." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Editorial,
});

function SectionHead({ n, kicker, title }: { n: string; kicker: string; title: string }) {
  return (
    <header className="mb-10 rule-double pt-4">
      <p className="text-xs font-semibold tracking-[0.2em] text-primary uppercase">
        {n} — {kicker}
      </p>
      <h2 className="mt-3 font-display text-5xl leading-[0.95] text-balance-tight md:text-7xl">{title}</h2>
    </header>
  );
}

function Editorial() {
  return (
    <div className="theme-editorial min-h-screen bg-background pb-24 font-sans text-foreground">
      {/* Masthead */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-3">
          <a href="#inicio" className="font-display text-2xl">Vida além da escala</a>
          <nav className="hidden gap-6 text-sm md:flex">
            {nav.map((n) => (
              <a key={n.id} href={`#${n.id}`} className="underline-offset-4 hover:text-primary hover:underline">
                {n.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6">
        {/* Início */}
        <section id="inicio" className="pt-12 pb-20">
          <div className="flex items-center justify-between border-y border-foreground py-2 text-xs tracking-widest uppercase">
            <span>{siteInfo.turma}</span>
            <span className="hidden sm:inline">Edição especial · Trabalho, corpo e tempo livre</span>
            <span>Nov 2026</span>
          </div>
          <h1 className="mt-10 animate-rise font-display text-6xl leading-[0.9] text-balance-tight md:text-[8.5rem]">
            Um dia a mais <em className="text-primary">para viver.</em>
          </h1>
          <div className="mt-10 grid gap-10 md:grid-cols-[1.6fr_1fr]">
            <figure>
              <img src={descanso} alt="Trabalhadora de supermercado descansando em um banco de parque no fim da tarde" width={1536} height={1024} className="aspect-[3/2] w-full object-cover" />
              <figcaption className="mt-2 text-xs text-muted-foreground">
                Com o fim da escala 6x1, a folga deixa de ser só recuperação e vira tempo de escolha.
              </figcaption>
            </figure>
            <div className="flex flex-col justify-between gap-8">
              <p className="text-xl leading-relaxed">{siteInfo.subtitulo}</p>
              <dl className="divide-y divide-border border-y border-border">
                {numeros.map((n) => (
                  <div key={n.valor} className="flex items-baseline justify-between gap-4 py-3">
                    <dt className="font-display text-4xl text-primary">{n.valor}</dt>
                    <dd className="max-w-[12rem] text-right text-sm text-muted-foreground">{n.rotulo}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </section>

        {/* Escala 6x1 */}
        <section id="escala" className="py-20">
          <SectionHead n="01" kicker="Entenda" title="O que é a escala 6x1" />
          <div className="grid gap-12 md:grid-cols-2">
            <p className="text-lg leading-relaxed first-letter:float-left first-letter:mr-3 first-letter:font-display first-letter:text-7xl first-letter:leading-[0.8] first-letter:text-primary">
              {escala.resumo}
            </p>
            <div className="space-y-6">
              {[{ nome: "Escala 6x1", dias: escala.semana6x1 }, { nome: "Escala 5x2", dias: escala.semana5x2 }].map((s) => (
                <div key={s.nome}>
                  <p className="mb-2 text-xs font-semibold tracking-widest uppercase">{s.nome}</p>
                  <div className="grid grid-cols-7 border border-foreground">
                    {s.dias.map((d, i) => (
                      <div
                        key={i}
                        className={`border-r border-foreground py-3 text-center text-xs last:border-r-0 ${d === "F" ? "bg-primary text-primary-foreground" : ""}`}
                      >
                        <span className="block font-semibold">{escala.dias[i]}</span>
                        <span className="block opacity-80">{d === "F" ? "Folga" : "Trabalho"}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-14 grid gap-8 border-t border-border pt-8 md:grid-cols-3">
            {escala.pontos.map((p) => (
              <article key={p.titulo}>
                <h3 className="font-display text-3xl">{p.titulo}</h3>
                <p className="mt-2 leading-relaxed text-muted-foreground">{p.texto}</p>
              </article>
            ))}
          </div>
        </section>

        {/* Lei aprovada */}
        <section id="lei" className="py-20">
          <SectionHead n="02" kicker="Congresso" title={`${lei.nome}: o fim da 6x1 virou Constituição`} />
          <div className="grid gap-12 md:grid-cols-[1fr_1.1fr]">
            <div>
              <p className="text-lg leading-relaxed">{lei.resumo}</p>
              <ul className="mt-8 space-y-5">
                {lei.mudancas.map((m) => (
                  <li key={m.titulo} className="border-l-2 border-primary pl-4">
                    <h3 className="font-semibold">{m.titulo}</h3>
                    <p className="text-muted-foreground">{m.texto}</p>
                  </li>
                ))}
              </ul>
            </div>
            <ol className="border-l border-foreground">
              {lei.linhaDoTempo.map((t) => (
                <li key={t.data} className="relative pb-7 pl-8 last:pb-0">
                  <span className="absolute top-1.5 -left-[5px] h-2.5 w-2.5 bg-primary" />
                  <p className="font-display text-2xl">{t.data}</p>
                  <p className="text-muted-foreground">{t.evento}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Perspectiva */}
        <section id="perspectiva" className="py-20">
          <SectionHead n="03" kicker="Educação Física" title="Corpo, lazer e bem-estar depois da 6x1" />
          <p className="max-w-3xl text-xl leading-relaxed">{perspectiva.introducao}</p>
          <p className="mt-3 text-xs tracking-widest text-muted-foreground uppercase">{perspectiva.credito}</p>
          <div className="mt-12 grid gap-px bg-border md:grid-cols-3">
            {perspectiva.eixos.map((e) => (
              <article key={e.titulo} className="bg-background p-6 md:first:pl-0">
                <p className="font-display text-5xl text-primary">{e.destaque}</p>
                <p className="text-xs text-muted-foreground">{e.destaqueRotulo}</p>
                <h3 className="mt-6 font-display text-3xl">{e.titulo}</h3>
                <p className="mt-2 leading-relaxed">{e.texto}</p>
              </article>
            ))}
          </div>
          <aside className="mt-12 bg-accent p-8 text-accent-foreground">
            <h3 className="font-display text-3xl">Desafios para que o tempo livre vire saúde</h3>
            <ul className="mt-4 grid gap-4 md:grid-cols-3">
              {perspectiva.desafios.map((d, i) => (
                <li key={d} className="flex gap-3">
                  <span className="font-display text-3xl text-primary">{i + 1}</span>
                  <span className="opacity-90">{d}</span>
                </li>
              ))}
            </ul>
          </aside>
        </section>

        {/* Resultados */}
        <section id="resultados" className="py-20">
          <SectionHead n="04" kicker="Pesquisa" title="Resultados e discussões" />
          <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
            <p className="text-muted-foreground">{resultados.amostra}</p>
            <p className="border border-primary px-3 py-1 text-primary">{resultados.aviso}</p>
          </div>
          <div className="mt-10 grid gap-12 md:grid-cols-2">
            <figure>
              <figcaption className="mb-4"><span className="font-semibold">Figura 1.</span> Dias de atividade física por semana</figcaption>
              <AtividadeFisicaChart />
            </figure>
            <figure>
              <figcaption className="mb-4"><span className="font-semibold">Figura 2.</span> Nível de cansaço ao fim da semana (escala 6x1)</figcaption>
              <CansacoChart />
            </figure>
            <figure>
              <figcaption className="mb-4"><span className="font-semibold">Figura 3.</span> Horas de lazer por semana</figcaption>
              <LazerChart />
            </figure>
            <figure>
              <figcaption className="mb-4"><span className="font-semibold">Figura 4.</span> O que fariam com o dia extra de folga</figcaption>
              <DiaExtraChart />
            </figure>
          </div>
          <div className="mt-14 grid gap-8 border-t border-border pt-8 md:grid-cols-3">
            {resultados.discussao.map((d, i) => (
              <p key={i} className="leading-relaxed">
                <span className="mr-2 font-display text-2xl text-primary">§{i + 1}</span>
                {d}
              </p>
            ))}
          </div>
          <p className="mt-6 text-xs tracking-widest text-muted-foreground uppercase">{resultados.credito}</p>
        </section>
      </main>

      <footer className="mx-auto max-w-6xl border-t border-foreground px-6 py-10 text-sm">
        <p className="font-display text-3xl">Vida além da escala</p>
        <p className="mt-2 text-muted-foreground">{siteInfo.turma} · Fontes: {lei.fontes.map((f, i) => (
          <span key={f.url}>
            <a href={f.url} target="_blank" rel="noreferrer" className="underline hover:text-primary">{f.nome}</a>
            {i < lei.fontes.length - 1 ? ", " : ""}
          </span>
        ))}</p>
      </footer>
      <LayoutSwitcher />
    </div>
  );
}

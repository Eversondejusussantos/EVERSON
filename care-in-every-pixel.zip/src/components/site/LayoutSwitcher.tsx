import { Link } from "@tanstack/react-router";
import { LayoutGrid } from "lucide-react";

const layouts = [
  { to: "/editorial", label: "1 · Editorial" },
  { to: "/painel", label: "2 · Painel" },
  { to: "/cartaz", label: "3 · Cartaz" },
] as const;

// Floating pill that lets visitors compare the three layouts.
export function LayoutSwitcher() {
  return (
    <nav
      aria-label="Escolher layout"
      className="fixed bottom-4 left-1/2 z-50 flex -translate-x-1/2 items-center gap-1 rounded-full border border-border bg-card/95 p-1 font-sans text-xs text-card-foreground shadow-card backdrop-blur"
    >
      <Link
        to="/"
        aria-label="Voltar para a escolha de layouts"
        className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-muted"
      >
        <LayoutGrid className="h-4 w-4" />
      </Link>
      {layouts.map((l) => (
        <Link
          key={l.to}
          to={l.to}
          className="rounded-full px-3 py-2 font-medium whitespace-nowrap hover:bg-muted"
          activeProps={{ className: "bg-primary text-primary-foreground hover:bg-primary" }}
        >
          {l.label}
        </Link>
      ))}
    </nav>
  );
}

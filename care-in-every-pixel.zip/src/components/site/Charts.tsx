import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { resultados } from "@/content/site";

// Chart colors come from the active theme's --chart-* tokens.
const tick = { fill: "var(--muted-foreground)", fontSize: 12, fontFamily: "var(--body-font)" };
const tooltipStyle = {
  background: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: "var(--radius)",
  color: "var(--card-foreground)",
  fontFamily: "var(--body-font)",
  fontSize: 13,
};
const pieColors = ["var(--chart-1)", "var(--chart-3)", "var(--chart-2)", "var(--chart-4)"];

export function AtividadeFisicaChart({ height = 280 }: { height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={resultados.atividadeFisica} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke="var(--border)" />
        <XAxis dataKey="dias" tick={tick} axisLine={false} tickLine={false} />
        <YAxis tick={tick} axisLine={false} tickLine={false} unit="%" />
        <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--muted)" }} formatter={(v) => `${v}%`} />
        <Legend wrapperStyle={{ fontSize: 12, fontFamily: "var(--body-font)", color: "var(--foreground)" }} />
        <Bar dataKey="escala6x1" name="Escala 6x1" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
        <Bar dataKey="escala5x2" name="Escala 5x2" fill="var(--chart-2)" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function CansacoChart({ height = 260 }: { height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Tooltip contentStyle={tooltipStyle} formatter={(v) => `${v}%`} />
        <Pie
          data={resultados.cansaco}
          dataKey="valor"
          nameKey="nivel"
          innerRadius="55%"
          outerRadius="90%"
          paddingAngle={2}
          stroke="var(--background)"
          strokeWidth={2}
        >
          {resultados.cansaco.map((item, i) => (
            <Cell key={item.nivel} fill={pieColors[i % pieColors.length]} />
          ))}
        </Pie>
        <Legend
          verticalAlign="bottom"
          wrapperStyle={{ fontSize: 12, fontFamily: "var(--body-font)", color: "var(--foreground)" }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}

export function LazerChart({ height = 220 }: { height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={resultados.lazerHoras} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke="var(--border)" />
        <XAxis dataKey="escala" tick={tick} axisLine={false} tickLine={false} />
        <YAxis tick={tick} axisLine={false} tickLine={false} unit="h" />
        <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--muted)" }} formatter={(v) => `${v} horas`} />
        <Bar dataKey="horas" name="Horas de lazer por semana" radius={[4, 4, 0, 0]}>
          {resultados.lazerHoras.map((item, i) => (
            <Cell key={item.escala} fill={i === 0 ? "var(--chart-1)" : "var(--chart-2)"} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function DiaExtraChart({ height = 280 }: { height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={resultados.diaExtra} layout="vertical" margin={{ top: 0, right: 16, left: 8, bottom: 0 }}>
        <CartesianGrid horizontal={false} stroke="var(--border)" />
        <XAxis type="number" tick={tick} axisLine={false} tickLine={false} unit="%" domain={[0, 100]} />
        <YAxis type="category" dataKey="uso" tick={tick} axisLine={false} tickLine={false} width={150} />
        <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--muted)" }} formatter={(v) => `${v}%`} />
        <Bar dataKey="valor" name="Entrevistados" fill="var(--chart-1)" radius={[0, 4, 4, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

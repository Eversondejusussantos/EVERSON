// Conteúdo compartilhado pelos três layouts do site sobre a escala 6x1.

export const siteInfo = {
  titulo: "Vida além da escala",
  subtitulo: "O fim da escala 6x1 e o que muda no corpo, no tempo livre e no bem-estar de quem trabalha.",
  turma: "Turma 632",
};

export const nav = [
  { id: "inicio", label: "Início" },
  { id: "escala", label: "Escala 6x1" },
  { id: "lei", label: "A lei aprovada" },
  { id: "perspectiva", label: "Perspectivas" },
  { id: "resultados", label: "Resultados" },
] as const;

export const numeros = [
  { valor: "15 mi", rotulo: "trabalhadores beneficiados, segundo o Governo Federal" },
  { valor: "44 → 40h", rotulo: "limite da jornada semanal" },
  { valor: "2 dias", rotulo: "de descanso remunerado por semana" },
  { valor: "75 × 1", rotulo: "placar da votação no Senado" },
];

export const escala = {
  resumo:
    "Na escala 6x1, a pessoa trabalha seis dias seguidos e tem apenas um dia de folga na semana. Até 2026, a Constituição permitia jornadas de até 8 horas por dia e 44 horas por semana — e o modelo 6x1 era a forma mais comum de cumprir esse limite em setores como comércio, supermercados, telemarketing, saúde e serviços.",
  pontos: [
    {
      titulo: "Um único dia para tudo",
      texto: "Descanso, tarefas de casa, consultas médicas, família e lazer precisam caber em 24 horas — e nem sempre essa folga cai no domingo.",
    },
    {
      titulo: "Quem mais vive essa rotina",
      texto: "Trabalhadores do comércio e dos serviços, em grande parte jovens, mulheres e pessoas de baixa renda que ainda gastam horas no transporte.",
    },
    {
      titulo: "Da internet ao Congresso",
      texto: "O movimento Vida Além do Trabalho (VAT) levou o debate às redes sociais e transformou a pauta em uma das mais discutidas do país.",
    },
  ],
  semana6x1: ["T", "T", "T", "T", "T", "T", "F"],
  semana5x2: ["T", "T", "T", "T", "T", "F", "F"],
  dias: ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"],
};

export const lei = {
  nome: "PEC 221/2019",
  resumo:
    "A Proposta de Emenda à Constituição 221/2019, apresentada pelo deputado Reginaldo Lopes (PT-MG) e relatada no Senado por Omar Aziz (PSD-AM), foi aprovada pelo Congresso e promulgada em 16 de outubro de 2026. A mudança acontece de forma gradual: ao final da transição, a regra passa a ser cinco dias de trabalho e dois de descanso.",
  mudancas: [
    { titulo: "Jornada menor", texto: "O limite semanal cai de 44 para 40 horas, com até 8 horas por dia." },
    { titulo: "Dois dias de descanso", texto: "Repouso semanal remunerado de dois dias, um deles preferencialmente no domingo." },
    { titulo: "Salário mantido", texto: "A redução da jornada não pode diminuir o salário do trabalhador." },
    { titulo: "Acordos coletivos", texto: "Compensação de horários e reduções maiores podem ser negociadas em acordo ou convenção coletiva." },
  ],
  linhaDoTempo: [
    { data: "2019", evento: "PEC 221/2019 é apresentada na Câmara dos Deputados." },
    { data: "2023–2024", evento: "O movimento VAT populariza o debate sobre o fim da escala 6x1." },
    { data: "Fev 2026", evento: "A Câmara coloca a proposta em pauta." },
    { data: "Maio 2026", evento: "A Câmara aprova a PEC por ampla maioria." },
    { data: "Set 2026", evento: "A Comissão de Constituição e Justiça do Senado aprova o texto." },
    { data: "14 out 2026", evento: "O Senado aprova em dois turnos: 75 votos a favor e 1 contra." },
    { data: "16 out 2026", evento: "O Congresso promulga a emenda à Constituição." },
  ],
  fontes: [
    { nome: "Agência Senado", url: "https://www12.senado.leg.br/noticias/materias/2026/10/14/senado-aprova-fim-da-escala-6x1-1" },
    { nome: "Agência Câmara", url: "https://www.camara.leg.br/noticias/1311742-congresso-promulga-o-fim-da-escala-6x1-e-aposentadoria-especial-para-agentes-de-saude" },
    { nome: "Planalto", url: "https://www.gov.br/planalto/pt-br/acompanhe-o-planalto/noticias/2026/10/congresso-promulga-emenda-a-constituicao-que-aprova-o-fim-da-escala-6x1" },
  ],
};

export const perspectiva = {
  credito: "Seção coordenada pela professora Geisa · trabalho desenvolvido pelos alunos",
  introducao:
    "Com um dia a mais de folga, o tempo deixa de ser apenas de recuperação e passa a ser também de escolha. Para a Educação Física, isso abre espaço para três demandas que a escala 6x1 costumava empurrar para depois: movimentar o corpo, viver o lazer e cuidar do bem-estar.",
  eixos: [
    {
      titulo: "Atividades físicas",
      texto:
        "A Organização Mundial da Saúde recomenda de 150 a 300 minutos de atividade física moderada por semana. Com dois dias livres, fica mais fácil incluir caminhadas, esportes, academia ou práticas em grupo sem sacrificar o sono.",
      destaque: "150–300 min",
      destaqueRotulo: "de atividade moderada por semana (OMS)",
    },
    {
      titulo: "Lazer",
      texto:
        "Lazer não é luxo: é um direito social previsto na Constituição. Parques, praças, cultura, passeios e brincadeiras com os filhos ganham espaço quando o segundo dia de folga não precisa ser gasto só com tarefas domésticas.",
      destaque: "Art. 6º",
      destaqueRotulo: "da Constituição inclui o lazer entre os direitos sociais",
    },
    {
      titulo: "Bem-estar",
      texto:
        "Menos horas de trabalho e mais descanso ajudam a reduzir o estresse, a exaustão e o risco de adoecimento. Dormir melhor, conviver com a família e ter tempo para si também são formas de cuidar da saúde.",
      destaque: "+1 dia",
      destaqueRotulo: "para descanso, sono e convivência",
    },
  ],
  desafios: [
    "Garantir espaços públicos de esporte e lazer perto de casa.",
    "Evitar que o dia extra vire um segundo emprego por necessidade financeira.",
    "Estimular programas de atividade física nas empresas e nos bairros.",
  ],
};

export const resultados = {
  credito: "Seção coordenada pela professora Alana",
  aviso: "Dados ilustrativos — substitua pelos resultados reais da pesquisa da turma.",
  amostra: "Amostra de exemplo: 120 trabalhadores (60 na escala 6x1 e 60 na escala 5x2).",
  atividadeFisica: [
    { dias: "0 dias", escala6x1: 38, escala5x2: 15 },
    { dias: "1 dia", escala6x1: 27, escala5x2: 18 },
    { dias: "2 dias", escala6x1: 18, escala5x2: 24 },
    { dias: "3 dias", escala6x1: 11, escala5x2: 25 },
    { dias: "4+ dias", escala6x1: 6, escala5x2: 18 },
  ],
  cansaco: [
    { nivel: "Muito alto", valor: 41 },
    { nivel: "Alto", valor: 31 },
    { nivel: "Moderado", valor: 20 },
    { nivel: "Baixo", valor: 8 },
  ],
  lazerHoras: [
    { escala: "Escala 6x1", horas: 5 },
    { escala: "Escala 5x2", horas: 11 },
  ],
  diaExtra: [
    { uso: "Descansar", valor: 68 },
    { uso: "Ficar com a família", valor: 61 },
    { uso: "Praticar atividade física", valor: 47 },
    { uso: "Lazer e cultura", valor: 39 },
    { uso: "Estudar", valor: 33 },
  ],
  discussao: [
    "Entre os trabalhadores da escala 6x1, a maior parte pratica atividade física no máximo um dia por semana. No grupo 5x2, a prática se distribui de forma mais equilibrada, com mais pessoas se exercitando três ou mais vezes.",
    "O cansaço aparece como principal barreira: mais de 70% dos entrevistados da escala 6x1 avaliam o próprio cansaço como alto ou muito alto ao fim da semana.",
    "Quando perguntados sobre o dia extra de folga, os entrevistados citam primeiro o descanso e a família — mas quase metade também quer usar esse tempo para se movimentar.",
  ],
};
